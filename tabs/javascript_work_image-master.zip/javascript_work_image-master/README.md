# ITGID.info
## Работаем с изображениями в JavaScript
### https://itgid.info

JavaScript работаем с изображениями. Получаем данные из файла, создаем и выводим img, добавляем описание и класс
### Посмотреть видеоурок на Youtube
https://youtu.be/bEuFi9OvgnA
[![Посмотреть видео](https://github.com/itgidinfo/javascript_work_image/blob/master/images/cover.png?raw=true)](https://youtu.be/bEuFi9OvgnA)

### Курсы ItGid.info

- JavaScript 2.0 (https://itgid.info/course/javascript-2)
- HTML для будущих JS разработчиков (https://itgid.info/course/html)
- Методы массивов JavaScript (https://itgid.info/course/arraymethod)
- ReactJS (https://itgid.info/course/reactjs)

В каждом курсе вас ждет много практических задач, поддержка, проверка ДЗ, разбор ошибок, помощью в решении
